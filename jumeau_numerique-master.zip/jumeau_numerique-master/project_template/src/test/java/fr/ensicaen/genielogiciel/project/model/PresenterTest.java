package fr.ensicaen.genielogiciel.project.model;

import fr.ensicaen.genielogiciel.project.presenter.Presenter;
import fr.ensicaen.genielogiciel.project.view.L10n;
import fr.ensicaen.genielogiciel.project.view.LoginView;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Locale;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class PresenterTest {

    @Mock
    private LoginView _view;
    private AutoCloseable closeable;

    @BeforeEach
    public void initMocks() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void closeService() throws Exception {
        closeable.close();
    }

    @Test
    void should_activate_view_error_display() {
        L10n.setLocale(Locale.FRENCH);
        // TODO Interest of this test holds on the use of Mockito
        // given
        Presenter presenter = new Presenter();
        presenter.setLoginView(_view);

        // when
        presenter.start("");

        // then
        verify(_view, times(1)).displayError(L10n.getMessageBundle().getString("error.nickname"));
    }
}