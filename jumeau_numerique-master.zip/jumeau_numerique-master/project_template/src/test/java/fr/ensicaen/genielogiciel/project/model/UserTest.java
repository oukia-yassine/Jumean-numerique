package fr.ensicaen.genielogiciel.project.model;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UserTest {
    @ParameterizedTest
    @CsvSource(
            {
                    "Toto",
                    "Un nom avec espace",
                    "Nom accentué",
            }
    )
    void should_get_nickname_when_set_nickname( String name ) {
        // FIXME This test is of no interest.
        //       It only shows the use of a parameterized test
        User loginModel = new User();
        loginModel.setNickname(name);
        assertEquals(name, loginModel.getNickname());
    }
}