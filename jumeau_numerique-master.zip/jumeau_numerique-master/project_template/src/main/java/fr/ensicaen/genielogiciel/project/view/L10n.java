package fr.ensicaen.genielogiciel.project.view;

import javax.swing.UIManager;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public final class L10n {
    // Note: L10n stands for Localization
    private static ResourceBundle _language;

    public static ResourceBundle getMessageBundle() {
        return ResourceBundle.getBundle("fr.ensicaen.genielogiciel.project.MessageBundle");
    }

    public static String getString( final String key ) {
        return _language.getString(key);
    }

    public static String getString( final String key, Object... arguments ) {
        final String pattern = _language.getString(key);
        final String filteredPattern = pattern.replace("'", "''");
        return MessageFormat.format(filteredPattern, arguments);
    }

    public static void setLocale( Locale locale ) {
        Locale.setDefault(locale);
        UIManager.getDefaults().setDefaultLocale(locale);
        _language = ResourceBundle.getBundle("fr.ensicaen.genielogiciel.project.MessageBundle", locale);
    }
}