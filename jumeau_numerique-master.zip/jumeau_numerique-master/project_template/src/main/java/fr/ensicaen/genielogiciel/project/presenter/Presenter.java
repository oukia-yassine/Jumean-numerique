package fr.ensicaen.genielogiciel.project.presenter;

import fr.ensicaen.genielogiciel.project.model.User;
import fr.ensicaen.genielogiciel.project.view.ImageViewer;
import fr.ensicaen.genielogiciel.project.view.L10n;
import fr.ensicaen.genielogiciel.project.view.LoginView;
import javafx.scene.image.Image;

import java.io.IOException;
import java.io.InputStream;

public final class Presenter {
    private final User _user = new User();
    private ILoginView _loginView;
    private ImageViewer _view;

    public void setLoginView( LoginView loginView ) {
        _loginView = loginView;
    }

    public void start( String nickname ) {
        if (nickname.isEmpty()) {
            _loginView.displayError(L10n.getString("error.nickname"));
        } else {
            _loginView.close();
            _user.setNickname(nickname);
            try {
                ImageViewer view = ImageViewer.ImageViewerFactory.createView();
                view.setPresenter(this);
                setView(view);
                view.setTitle(_user.getNickname());
                view.show();
            } catch (IOException ignored) {
                // Nothing to do
            }
        }
    }

    public void setView( ImageViewer view ) {
        _view = view;
    }

    public void exitApplication() {
        System.exit(0);
    }

    public void displayImage() {
        InputStream resourceAsStream = getClass().getResourceAsStream("/fr/ensicaen/genielogiciel/project/images/image.png");
        if (resourceAsStream != null) {
            Image image = new Image(resourceAsStream);
            _view.displayImage(image);
        }
    }

    public String getUsername() {
        return _user.getNickname();
    }
}
