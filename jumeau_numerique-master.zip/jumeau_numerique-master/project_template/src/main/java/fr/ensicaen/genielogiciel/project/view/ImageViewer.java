package fr.ensicaen.genielogiciel.project.view;

import fr.ensicaen.genielogiciel.project.Main;
import fr.ensicaen.genielogiciel.project.presenter.Presenter;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public final class ImageViewer {
    private static Stage _stage;
    @FXML
    private Label titleLabel;
    @FXML
    private ImageView imageView;
    private Presenter _presenter;

    public void show() {
        _stage.show();
    }

    public void setPresenter( Presenter presenter ) {
        _presenter = presenter;
    }

    public void displayImage( Image image ) {
        imageView.setImage(image);
    }

    public void setTitle( String username ) {
        String message = L10n.getString("project.hello", username);
        titleLabel.setText(message);
    }

    @FXML
    private void onDisplayImage() {
        _presenter.displayImage();
    }

    @FXML
    private void exitApplication() {
        _presenter.exitApplication();
    }

    public static final class ImageViewerFactory {
        private ImageViewerFactory() {
            // Factory class as Utility class where the constructor is private
        }

        public static ImageViewer createView() throws IOException {
            final FXMLLoader loader = new FXMLLoader(LoginView.class.getResource("ImageViewer.fxml"), L10n.getMessageBundle());
            final Parent root = loader.load();
            final ImageViewer view = loader.getController();
            final Scene scene = new Scene(root, 800, 600);
            final Stage stage = new Stage();
            stage.setTitle(L10n.getString("project.title"));
            stage.setScene(scene);
            _stage = stage;
            return view;
        }
    }
}