package fr.ensicaen.genielogiciel.project;

import fr.ensicaen.genielogiciel.project.presenter.Presenter;
import fr.ensicaen.genielogiciel.project.view.L10n;
import fr.ensicaen.genielogiciel.project.view.LoginView;
import javafx.application.Application;
import javafx.stage.Stage;

import java.util.Locale;

public final class Main extends Application {

    private Presenter _presenter;

    @Override
    public void start( final Stage primaryStage ) throws Exception {
        final Locale locale = new Locale.Builder().setLanguage("fr").setRegion("FR").build();
        L10n.setLocale(locale);
        primaryStage.setTitle(L10n.getString("project.title"));
        LoginView view = LoginView.LoginViewFactory.createView(primaryStage);
        _presenter = new Presenter();
        _presenter.setLoginView(view);
        view.setPresenter(_presenter);
        view.show();
    }

    @Override
    public void stop() {
        System.out.println(L10n.getString("project.bye", _presenter.getUsername()));
    }
}