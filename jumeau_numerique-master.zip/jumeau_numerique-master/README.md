# jumeau_numerique

## description


## Members

Chef de projet : Sebastien VOIRIN
Responsable de version : Lorine BENETEAU--DESMOULIERES
Architectes : Julien RAVENT, Yassine OUKIA
Developpeurs : Sebastien VOIRIN, Lorine BENETEAU--DESMOULIERES, Julien RAVENT, Yassine OUKIA, Anass BENAGUESSIM, Yassir DOURAID, Adam BEHATE, ...
